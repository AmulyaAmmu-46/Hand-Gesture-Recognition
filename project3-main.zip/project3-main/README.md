Step 1: install all the modules
Step 2: Convert Your presetations slides into png file format
Step 3: Change the paths in the code according to your file directory/path
Step 4: Run the main.py file
_______________________________________________________________________________
For controling slides follow the steps given below:
For Changing to next slide - use little finger above the green line in the frame
For Changing to previous slide - use your thumb above the green line in the frame
For Pointing Out something in the slide - use two fingers i.e your index finger along with your middle finger 
For underlining something in the slide - use only index finger
For erasing the last underlines or marks - use three fingers i.e ypur index finger, your middle finger and your ring finger all together
